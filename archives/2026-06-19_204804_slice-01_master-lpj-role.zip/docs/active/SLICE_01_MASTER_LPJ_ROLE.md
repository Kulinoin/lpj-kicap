# Slice 01 — Master LPJ & Role

## Status

Implemented, validation script ready.

## Target

- Role Admin/User.
- Profil lembaga.
- Tipe LPJ.
- Status LPJ.
- Struktur awal data kegiatan.
- Data user seed.

## Implementasi

### Database

- Menambahkan kolom role dan izin dasar pada tabel users:
  - role
  - is_active
  - can_create_lpj
  - can_transfer_balance
- Menambahkan tabel:
  - organization_profiles
  - lpj_types
  - lpjs
  - lpj_assigned_users

### Model

- User
- OrganizationProfile
- LpjType
- Lpj
- LpjAssignedUser

### Seed

- Admin:
  - admin@kicap.id
  - password
- User:
  - user@kicap.id
  - password
- Pendamping:
  - pendamping@kicap.id
  - password
- Profil lembaga awal:
  - PT. Kazoku Indonesia Center
  - Lembaga Pelatihan Kerja
- Tipe LPJ awal:
  - Penyelenggaraan Event
  - Pendampingan Peserta Seleksi
  - Delegasi / Perwakilan
  - Bantuan Dana / Sponsorship
  - Kegiatan Internal
- Demo LPJ awal:
  - LPJ-DEMO-001

### Filament

Resource dibuat menggunakan generator Filament terpasang:

- User
- OrganizationProfile
- LpjType
- Lpj

Admin dapat mengelola master dasar dari backoffice.

### PWA/API sanity endpoint

- GET `/api/master/lpj-types`

Endpoint ini disiapkan sebagai sumber awal tipe LPJ untuk PWA.

## Validasi Otomatis

- `php artisan migrate --seed`
- `php artisan test --filter=Slice01MasterLpjRoleTest`
- `php artisan route:list`
- `php artisan optimize:clear`

## Validasi Manual

- Admin login ke panel.
- User seed tersedia.
- Admin melihat menu resource master.
- User tidak diberi akses ke panel Admin.
- Tipe LPJ tersedia.
- LPJ demo awal tersedia.
- Endpoint `/api/master/lpj-types` mengembalikan 5 tipe LPJ.

## Catatan

- Slice ini belum mengerjakan wizard narasi.
- Slice ini belum mengerjakan transaksi, saldo, dana talangan, dan dokumen PDF.
- Transfer saldo tetap mengikuti lock konsep: tanpa approval Admin, tetapi implementasi mutasi saldo baru masuk Slice 03.

# Progress Kicap Event

## Decision 2026-06-20 — Kicap Event

Konsep terbaru:

```text
Event / Kegiatan = objek utama yang dikelola aplikasi
LPJ = output akhir/dokumen hasil dari event/kegiatan
```

Catatan progres lama yang menyebut LPJ sebagai objek kerja dibaca sebagai legacy wording untuk Event/Kegiatan, kecuali konteksnya dokumen final/export/template LPJ.

## Slice 07 — MVP Polish & Siap Pakai

Status: Implementasi User PWA polish, admin dashboard polish, aset resmi aplikasi, dan panduan deploy VPS selesai; validasi otomatis PASS, siap commit/push.

Selesai:

- User PWA Beranda dipoles mengikuti brief/screenshot: sapaan, avatar menuju Profil, lembaga, online/offline indicator, statistik Aktif/Selesai/Tugas, Event Aktif, dan transaksi terakhir.
- User PWA memiliki layar Daftar Event dengan search, filter `Semua/Aktif/Selesai/Tugas`, kartu event mobile, progress, badge status, dan chevron.
- User Profil dipoles menjadi layar profil mobile dengan avatar besar, statistik, menu Personal Information, Activity History, Settings, dan Logout.
- Avatar profil langsung upload saat dipilih.
- Personal Information autosave ringan saat field blur/back.
- Settings password memakai password lama sebelum update.
- Bottom navigation User diurutkan sesuai brief: Beranda, Operasional, Keuangan, Dokumentasi, Catatan.
- Payload PWA menambahkan data ringkasan berbasis data nyata: role penugasan, jumlah peserta, progress, transaksi terakhir, lembaga, role label, dan tahun member.
- Login Filament dipoles dengan logo resmi Kicap, field proporsional, footer `V2.4.1 © 2026 Kulino`, dan tanpa frame hitam.
- Admin dashboard default Filament diganti dengan dashboard operasional Kicap Event.
- Tabel Admin `Users` menampilkan kolom avatar/foto profil.
- Favicon dan logo aplikasi diganti memakai aset resmi Kicap dengan nama file `kicap-event-*`.
- Panduan deploy VPS untuk domain `lpj.kicap.id` tersedia di `docs/deploy/VPS_LPJ_KICAP_ID_DEPLOY.md`.
- Tidak mengubah guardrail role, status event, transfer saldo, LPJ final, atau schema/model/route internal `lpj`.

Validasi otomatis PASS:

- `npm run build`
- `php -l routes/web.php`
- `php artisan test tests/Feature/Slice01UsernameLoginFormTest.php tests/Feature/Slice02LpjDetailMobileInputTest.php tests/Feature/Slice03OperationalFinanceTest.php tests/Feature/Slice04ExecutionDocumentationTest.php` — 28 tests, 126 assertions
- `php artisan test tests/Feature/Slice05ReviewFinalizationTest.php tests/Feature/Slice06ReportGenerationTest.php` — 7 tests, 53 assertions
- `php artisan migrate:fresh --seed -n`
- `php artisan route:list --path=api/app`
- `php artisan route:list --path=app`
- `php artisan test tests/Feature/HealthCheckTest.php` — 3 tests, 4 assertions
- `php artisan test` — 53 tests, 222 assertions
- `git diff --check`

Catatan runtime:

- Playwright dengan Chrome lokal berhasil login sebagai User dan merender screen Beranda, Daftar Event, dan Profil.
- PHP local server merespons lambat pada request awal, sehingga bukti final tetap mengandalkan test/build/artisan dan review manual user.

## Slice 00 — Project Foundation

Status: Implementasi + patch cache + patch timezone + patch PHPUnit tests + validasi otomatis + archive final.

### Selesai

- Laravel foundation.
- Filament admin baseline.
- React PWA baseline.
- MySQL Docker isolated.
- Port unik agar tidak bentrok.
- Health check.
- README awal.
- Docs active.
- Patch cache Laravel agar tidak memakai database sebelum migration.
- Patch timezone aplikasi ke Asia/Jakarta.
- Patch phpunit.xml agar cocok dengan environment Slice 00.
- Patch test bawaan ke PHPUnit class-style.
- Archive final dibuat setelah validasi pass.

### Validasi PASS

- php artisan migrate --force
- php artisan test
- npm run build
- /health HTTP 200 dan database ok
- /app HTTP 200
- /admin HTTP 302
- Git remote SSH benar

### Belum

- Commit.
- Push.
- Role Admin/User detail.
- Master Event.
- Data model LPJ.

### Next Slice Revisi

Slice 01 — Master Event, Role, Login, dan UI Baseline.

## Slice 01 — Master Event & Role

Status: Reset dan akan dikerjakan ulang dari awal.

Alasan reset:

- LPJ hanya dibuat oleh Admin.
- User hanya input operasional.
- Status event/kegiatan disederhanakan menjadi `draft`, `aktif`, `finish`, `arsipkan`.
- User hanya melihat LPJ `aktif` dan `finish`.
- Login menjadi satu halaman berbasis role.
- `Ingat saya` wajib berjalan.
- User PWA memakai bottom navigation mengambang.
- Admin panel dibuat full-width.

Target baru tercatat di `docs/active/SLICE_01_MASTER_LPJ_ROLE.md`.

## Slice 01 Revisi — Implementasi 2026-06-20

Status: Implementasi + validasi otomatis PASS, disetujui untuk commit/push pada 20 Juni 2026.

Selesai:

- Login tunggal Admin/User memakai field username/email dan password.
- Redirect role setelah login: Admin ke `/admin`, User ke `/app`.
- Checkbox `Ingat saya` dipertahankan dan teruji menghasilkan remember token.
- User role ditolak dari panel Admin.
- Status event/kegiatan dikunci ke `draft`, `aktif`, `finish`, `arsipkan`.
- Seed user MVP: Admin dapat membuat LPJ, User/Pendamping tidak dapat membuat LPJ.
- Endpoint PWA `/api/app/lpjs` hanya menampilkan LPJ assigned berstatus `aktif` dan `finish`.
- Admin resource LPJ memakai pilihan status terkunci dan assignment user.
- Admin panel memakai layout full-width.
- User PWA baseline responsive dengan bottom navigation mengambang.

Validasi otomatis PASS:

- `php artisan migrate:fresh --seed`
- `php artisan test` — 26 tests, 59 assertions
- `php artisan route:list --path=admin`
- `cmd.exe /c "cd /d D:\kulino\lpj-kicap && npm.cmd run build"`

Catatan runtime:

- `npm run build` dari bash gagal karena `npm` Windows tidak bisa membaca shim Vite Linux.
- Build PASS setelah `npm install --ignore-scripts` lewat Windows npm melengkapi optional native dependency Rolldown, lalu build dijalankan via `cmd.exe`.

## Slice 02 — LPJ Detail & Input Mobile

Status: Implementasi + validasi otomatis PASS, menunggu review manual user sebelum commit/push.

Selesai:

- Halaman detail LPJ untuk User di PWA mobile.
- Endpoint detail LPJ hanya untuk User yang ditugaskan.
- LPJ `aktif` dapat diisi catatan operasionalnya oleh User yang ditugaskan.
- LPJ `finish` tampil read-only untuk User yang ditugaskan.
- Narasi LPJ tidak tampil dan tidak dapat diedit oleh User/Petugas.
- Autosave ringan untuk catatan operasional mobile.
- Bottom navigation petugas menjadi 5 item dengan `Input Cepat` sebagai tombol tengah.
- Label UX PWA yang terlihat user memakai bahasa Indonesia, termasuk `Input Cepat` dan `Selesai`.

Validasi otomatis PASS:

- `php artisan migrate --force`
- `php artisan test tests/Feature/Slice02LpjDetailMobileInputTest.php` — 5 tests, 27 assertions
- `php artisan test` — 34 tests, 99 assertions
- `php artisan migrate:fresh --seed`
- `php artisan route:list --path=api/app`
- `cmd.exe /c "cd /d D:\kulino\lpj-kicap && npm.cmd run build"`

## Slice 03 — Operasional Keuangan

Status: Implementasi + validasi otomatis PASS, menunggu review manual user sebelum commit/push.

Selesai:

- Menambahkan data model dana masuk LPJ, saldo pegangan user, mutasi saldo, transaksi operasional, dan klaim dana talangan.
- Menambahkan service transaksi keuangan berbasis DB transaction.
- Admin dapat mencatat dana masuk LPJ dan dana pegangan user melalui Filament.
- Admin dapat melihat saldo user, mutasi saldo, transaksi operasional, dan klaim talangan.
- User PWA dapat melihat saldo pada detail LPJ.
- User PWA dapat mencatat pengeluaran dari saldo pegangan dengan bukti atau alasan tanpa bukti.
- User PWA dapat transfer saldo antar user yang ditugaskan tanpa approval Admin.
- User PWA dapat mencatat dana talangan dan sistem membuat klaim internal.
- Transfer saldo tidak membuat transaksi pengeluaran LPJ.
- LPJ `finish` tetap read-only untuk input keuangan.
- Follow-up review: sumber dana masuk dijadikan pilihan `Lembaga/Sponsor/Dinas`.
- Follow-up review: kategori transaksi User dijadikan pilihan tetap.
- Follow-up review: `Input Operasional` dan `Operasional Keuangan` dipisah menjadi menu bawah `Operasional` dan `Keuangan`.
- Follow-up review: kolom `User Terkait Transfer` diberi placeholder `-` untuk mutasi non-transfer.

Validasi otomatis PASS:

- `php artisan test tests/Feature/Slice03OperationalFinanceTest.php` — 6 tests, 31 assertions
- `php artisan route:list --path=api/app`
- `php artisan route:list --path=admin`
- `php artisan test tests/Feature/Slice02LpjDetailMobileInputTest.php` — 5 tests, 27 assertions
- `php artisan test` — 40 tests, 130 assertions
- `php artisan migrate:fresh --seed -n`
- `cmd.exe /c "cd /d D:\kulino\lpj-kicap && npm.cmd run build"`

## Slice 04 — Pelaksanaan & Dokumentasi

Status: Implementasi + validasi otomatis PASS, menunggu review manual user sebelum commit/push.

Selesai:

- Menambahkan data model peserta kegiatan, panitia/pendamping, rundown, dokumentasi kegiatan, dan lampiran pendukung.
- Menambahkan `ActivityExecutionService` untuk menyimpan data pelaksanaan dan upload dokumentasi/lampiran.
- Endpoint detail LPJ User menampilkan payload pelaksanaan/dokumentasi untuk LPJ yang ditugaskan.
- User PWA dapat input peserta, panitia/pendamping, dan rundown pada tab `Operasional`.
- User PWA dapat upload dokumentasi kegiatan dan lampiran pendukung.
- Catatan operasional menambahkan `Evaluasi` dan bisa dipilih `Masuk LPJ`.
- LPJ `finish` tetap read-only untuk input pelaksanaan dan upload dokumentasi.
- Guardrail Slice 03 tetap: transfer saldo tidak diubah dan tidak menjadi pengeluaran LPJ.
- Tidak membuat endpoint PDF resmi/final pada Slice 04.

Validasi otomatis PASS:

- `php artisan migrate --force`
- `php artisan test tests/Feature/Slice04ExecutionDocumentationTest.php` — 5 tests, 29 assertions
- `php artisan route:list --path=api/app`
- `php artisan test tests/Feature/Slice02LpjDetailMobileInputTest.php` — 5 tests, 28 assertions
- `php artisan test tests/Feature/Slice03OperationalFinanceTest.php` — 6 tests, 32 assertions
- `php artisan test` — 45 tests, 161 assertions
- `php artisan migrate:fresh --seed -n`
- `npm run build`

## Product Concept Rename — Kicap Event

Status: Dokumentasi konsep + label UI aman diperbarui + validasi otomatis PASS, menunggu review manual user sebelum commit/push.

Selesai:

- Membuat decision doc `docs/decisions/DECISION_2026-06-20_KICAP_EVENT_RENAME.md`.
- Mengunci vocabulary: Event/Kegiatan sebagai objek utama, LPJ sebagai output dokumen akhir.
- Memperbarui README, AGENTS, PRD, workflow, role-permission, data model, roadmap, dan dokumen aktif agar keputusan terbaru menjadi panduan berikutnya.
- Mengubah label user-facing yang aman dari LPJ-as-object menjadi Event/Kegiatan.
- Tidak melakukan rename schema/model/route/service internal.

Validasi PASS:

- `rg` sisa istilah LPJ untuk review konteks.
- `php artisan route:list`
- `php artisan config:clear`
- `php artisan view:clear`
- `npm run build`
- `php artisan test tests/Feature/HealthCheckTest.php`

Archive:

- `archives/2026-06-20_210040_kicap-event-concept-rename.zip`

## Slice 05 — Review & Finalisasi Event

Status: Implementasi + validasi otomatis berjalan, menunggu review manual user sebelum commit/push.

Selesai:

- Menambahkan `LpjReviewService` untuk submit review, checklist kelengkapan, review transaksi, revisi transaksi, rekonsiliasi sederhana, dan finalisasi.
- User PWA dapat mengajukan event/kegiatan aktif untuk review Admin.
- User PWA dapat mengirim revisi transaksi miliknya saat Admin menandai transaksi `Perlu Revisi` atau `Menunggu Bukti`.
- Admin dapat melihat checklist finalisasi melalui action pada tabel Event.
- Admin dapat menandai transaksi sebagai `Valid`, `Ditolak`, `Perlu Revisi`, atau `Menunggu Bukti` melalui tabel Transaksi Event.
- Transaksi tanpa bukti tidak dapat divalidasi jika tidak memiliki alasan.
- Total pengeluaran valid dan sisa dana dihitung ulang dari transaksi berstatus `valid`.
- Admin dapat mengunci event/kegiatan menjadi `finish` hanya setelah checklist finalisasi PASS.
- Event/kegiatan `finish` tetap read-only untuk input User.
- Tidak membuat endpoint PDF resmi/final pada Slice 05.

Validasi otomatis PASS:

- `php artisan test tests/Feature/Slice05ReviewFinalizationTest.php` — 4 tests, 20 assertions
- `php artisan test tests/Feature/Slice02LpjDetailMobileInputTest.php` — 5 tests, 28 assertions
- `php artisan test tests/Feature/Slice03OperationalFinanceTest.php` — 6 tests, 32 assertions
- `php artisan test tests/Feature/Slice04ExecutionDocumentationTest.php` — 5 tests, 29 assertions
- `php artisan route:list --path=api/app`
- `php artisan route:list --path=admin`
- `npm run build`
- `php artisan test` — 49 tests, 181 assertions
- `php artisan migrate:fresh --seed -n`

Follow-up UX/Admin 2026-06-20:

- User PWA: menu bawah `Selesai` diganti menjadi `Dokumentasi`.
- User PWA: dashboard menampilkan event terbaru dengan prioritas event aktif.
- User PWA: kartu event dibuat lebih modern dan font weight diturunkan agar tidak terasa penuh.
- Admin Event: form Event dirapikan dari placeholder system Filament, sumber dana menjadi select `Lembaga/Sponsor/Dinas`, dan field audit/finalisasi tidak tampil sebagai input manual.
- Admin Event: create/edit kembali ke list utama setelah simpan.
- Admin Event: list Event dipadatkan ke kolom penting.
- Admin Event: action cepat status ditambahkan, `Aktif` untuk draft dan `Selesai` untuk aktif dengan guardrail checklist finalisasi.
- Admin Dana: select Event/User pada Dana Masuk dan Mutasi Saldo diberi prompt yang jelas.

Validasi fokus PASS:

- `php -l` file Filament yang dipatch.
- `npm run build`.
- `php artisan route:list --path=admin`.
- `php artisan route:list --path=api/app`.
- `php artisan test tests/Feature/Slice01MasterLpjRoleTest.php` — 7 tests, 24 assertions.
- `php artisan test tests/Feature/Slice05ReviewFinalizationTest.php` — 4 tests, 20 assertions.
- `php artisan tinker --execute='...'` form smoke — `forms ok`.

## Slice 06 — Generate Dokumen LPJ

Status: Implementasi + validasi otomatis fokus PASS, menunggu review manual user sebelum commit/push.

Selesai:

- Menambahkan dependency `barryvdh/laravel-dompdf` untuk export PDF server-side.
- Menambahkan `LpjReportService` untuk menyusun payload LPJ final dari event/kegiatan `finish`.
- Menambahkan print-ready view formal LPJ dengan cover, halaman pengesahan, footer/nomor halaman, identitas kegiatan, pelaksanaan, keuangan global, transaksi valid, dokumentasi, lampiran, dan penutup.
- Menambahkan route Admin `admin/reports/lpjs/{lpj}/print` dan `admin/reports/lpjs/{lpj}/pdf`.
- Menambahkan action Admin `Preview LPJ` dan `PDF LPJ` pada tabel Event, hanya tampil untuk event/kegiatan `finish`.
- Output final hanya mengambil transaksi berstatus `valid`.
- Transfer saldo, saldo per user, klaim/reimbursement, transaksi ditolak, catatan internal, serta dokumentasi/lampiran yang tidak ditandai `Masuk LPJ` tidak tampil default di LPJ final.
- Dana talangan yang sudah valid tetap tampil sebagai biaya kegiatan.
- User tetap tidak dapat membuat/generate LPJ final.

Validasi otomatis PASS:

- `php -l app/Services/LpjReportService.php`
- `php -l routes/web.php`
- `php -l tests/Feature/Slice06ReportGenerationTest.php`
- `php artisan test tests/Feature/Slice06ReportGenerationTest.php` — 2 tests, 19 assertions
- `php artisan test tests/Feature/Slice05ReviewFinalizationTest.php` — 4 tests, 20 assertions
- `php artisan test tests/Feature/Slice04ExecutionDocumentationTest.php` — 5 tests, 29 assertions
- `php artisan route:list --path=admin`
- `php artisan route:list --path=api/app`
- `npm run build`
- `php artisan migrate:fresh --seed -n`
- `git diff --check`

Catatan validasi:

- Kombinasi test Slice 04 + Slice 05 dalam satu command melewati timeout runtime lokal, lalu dijalankan terpisah dan keduanya PASS.

Follow-up dana/print 2026-06-20:

- Menambahkan aturan bahwa total dana yang dialokasikan Admin ke user untuk satu event tidak boleh lebih besar dari dana masuk event.
- `Dana Masuk Event` menampilkan `Alokasi Dana` dan `Sisa Alokasi` untuk membantu Admin memantau plafon dana.
- Payload keuangan User menampilkan `allocated_fund` dan `remaining_allocation`.
- User yang ditugaskan dapat membuka print preview LPJ untuk event/kegiatan `finish`.
- Tombol `Cetak LPJ` tampil pada detail event selesai di PWA User.
- PDF export Admin tetap tersedia, tetapi jalur ringan utama untuk User adalah print preview HTML.

Validasi follow-up PASS:

- `php artisan test tests/Feature/Slice03OperationalFinanceTest.php` — 7 tests, 38 assertions
- `php artisan test tests/Feature/Slice06ReportGenerationTest.php` — 2 tests, 26 assertions
- `php artisan test tests/Feature/Slice01MasterLpjRoleTest.php tests/Feature/Slice01UsernameLoginFormTest.php tests/Feature/Slice01ProfileLoginPatchTest.php tests/Feature/Slice01ProfileAvatarPasswordPatchTest.php tests/Feature/Slice02LpjDetailMobileInputTest.php` — 29 tests, 93 assertions
- `php artisan test tests/Feature/Slice04ExecutionDocumentationTest.php tests/Feature/Slice05ReviewFinalizationTest.php` — 9 tests, 49 assertions
- `php artisan route:list --path=app/lpjs`
- `php artisan route:list --path=api/app`
- `npm run build`
- `php artisan migrate:fresh --seed -n`
- `git diff --check`

Follow-up Dokumen LPJ 2026-06-20:

- Menambahkan tabel snapshot `lpj_report_snapshots`.
- Menambahkan menu Admin `Dokumen LPJ`.
- Setiap Admin/User membuka print preview LPJ final atau Admin export PDF, sistem menyimpan snapshot HTML print-ready.
- Snapshot menyimpan nomor versi, event, user pembuat, sumber generate, total dana masuk, total pengeluaran valid, total sisa dana, waktu generate, dan HTML dokumen.
- Admin dapat membuka ulang snapshot dari menu `Dokumen LPJ`.

Validasi follow-up PASS:

- `php -l` model/service/route/resource/test terkait snapshot
- `php artisan migrate:fresh --seed -n`
- `php artisan test tests/Feature/Slice06ReportGenerationTest.php` — 3 tests, 32 assertions
- `php artisan test tests/Feature/Slice03OperationalFinanceTest.php` — 7 tests, 38 assertions
- `php artisan route:list --path=admin`
- `npm run build`
- `git diff --check`

Follow-up PWA User 2026-06-20:

- Memisahkan tampilan role User: menu `Operasional` hanya berisi catatan petugas, peserta, panitia/pendamping, dan rundown.
- Upload dokumentasi, upload lampiran, dan daftar file tersimpan dipindahkan penuh ke menu `Dokumentasi`.
- Klik event dari `Beranda` sekarang membuka detail event read-only, bukan masuk ke menu `Operasional`.
- Detail event dari `Beranda` hanya menampilkan informasi event dan akses `Cetak LPJ` jika LPJ sudah tersedia.
- API/data model tidak berubah; perubahan hanya pada pemisahan halaman PWA.

Validasi follow-up PASS:

- `npm run build`
- `php artisan test tests/Feature/Slice04ExecutionDocumentationTest.php tests/Feature/Slice02LpjDetailMobileInputTest.php` — 10 tests, 57 assertions
- `php artisan test tests/Feature/Slice02LpjDetailMobileInputTest.php tests/Feature/Slice06ReportGenerationTest.php` — 8 tests, 60 assertions
- `php artisan route:list --path=api/app`
- `git diff --check`

Follow-up Storage, Logo, dan Catatan 2026-06-21:

- Menambahkan pengaturan Admin `Pengaturan Penyimpanan` untuk memilih Local Storage atau Cloudflare R2.
- Menambahkan dependency S3 adapter agar Cloudflare R2 dapat dipakai lewat driver storage S3-compatible.
- Dokumentasi kegiatan, lampiran, bukti transaksi, dan avatar profil sekarang menyimpan metadata disk agar URL tetap benar saat pindah provider.
- Upload gambar dokumentasi/lampiran/proof/avatar disiapkan untuk kompres otomatis ke WebP saat runtime server memiliki GD/WebP.
- Runtime lokal saat validasi belum memiliki GD/WebP, sehingga sistem fallback aman ke file asli.
- Menu `Organization Profiles` memakai upload gambar `Logo Lembaga untuk LPJ`, bukan input teks path.
- Menambahkan panduan aset aplikasi di `docs/active/APP_ASSET_GUIDE.md`.
- Favicon browser fallback `public/favicon.ico` didaftarkan di halaman PWA dan asset PWA build.
- Bottom navigation User mengganti `Profil` menjadi `Catatan`.
- Menu `Catatan` menjadi tempat input catatan petugas.
- Menu `Operasional` hanya berisi data pelaksanaan: peserta, tim/panitia/pendamping, dan rundown.
- Tombol `Beranda` selalu kembali ke layar awal ringkasan dan daftar event, bukan mempertahankan detail event terakhir.

Validasi follow-up PASS:

- `php -l` file PHP yang dipatch.
- `php artisan migrate:fresh --seed -n`
- `php artisan test tests/Feature/Slice04ExecutionDocumentationTest.php tests/Feature/Slice06ReportGenerationTest.php` — 8 tests, 64 assertions.
- `php artisan test tests/Feature/Slice01UsernameLoginFormTest.php tests/Feature/Slice01ProfileLoginPatchTest.php tests/Feature/Slice01ProfileAvatarPasswordPatchTest.php tests/Feature/Slice02LpjDetailMobileInputTest.php tests/Feature/Slice03OperationalFinanceTest.php` — 29 tests, 107 assertions.
- `php artisan route:list --path=admin`
- `php artisan route:list --path=api/app`
- `php artisan route:list --path=app/lpjs`
- `npm run build`

Catatan validasi:

- `composer dump-autoload --no-scripts --no-interaction` timeout pada fase `Generating optimized autoload files`, tetapi autoload sudah dapat membaca S3 adapter dan service aplikasi.


## Patch 2026-06-23 16:54:58 — Patch PWA — Unified Finance Form

- Menggabungkan 3 form PWA Keuangan menjadi 1 form dinamis Catat Keuangan.
- Jenis catatan: Pengeluaran Saldo Pegangan, Pengeluaran Dana Talangan/Dana Pribadi, Transfer Saldo.
- Endpoint backend tetap memakai flow lama: expenses, advance-expenses, balance-transfers.
- Upload bukti tetap memakai normalisasi/kompresi gambar yang sudah stabil.
- Tidak mengubah struktur database dan tidak menjalankan migrasi.


## Patch 2026-06-23 17:07:02 — Patch PWA — Finance History Latest 10

- Riwayat terbaru pada PWA Keuangan dibatasi menjadi 10 transaksi terakhir.
- Menambahkan tombol Lihat semua sejajar dengan judul Riwayat terbaru.
- Mode Semua riwayat menampilkan seluruh transaksi dan tetap bisa klik baris untuk detail minimal.
- Tidak mengubah backend, database, maupun endpoint.


## Patch 2026-06-23 17:12:31 — Patch PWA — Finance History Latest 10 + See All

- Riwayat terbaru PWA Keuangan tampil maksimal 10 transaksi terakhir.
- Tombol Lihat semua ditambahkan sejajar dengan judul Riwayat terbaru.
- Backend finance payload dipastikan tidak membatasi transaksi hanya 10 agar semua riwayat bisa ditampilkan saat diminta.
- Tidak mengubah struktur database dan tidak menjalankan migrasi.


## Patch 2026-06-23 17:17:06 — Patch PWA — Finance History See All Link Look

- Mengubah visual tombol Lihat semua pada Riwayat terbaru menjadi label/link ringan seperti pola Beranda.
- Fungsi tetap sama: toggle 10 terakhir dan semua riwayat.
- Tidak mengubah backend, database, maupun endpoint.


## Patch 2026-06-24 13:13:37 — Patch PWA — Transfer Saldo in Finance History

- Transfer saldo kini muncul di Riwayat terbaru/Semua riwayat PWA Keuangan.
- Transfer tetap dicatat sebagai mutasi saldo internal, bukan transaksi LPJ final.
- Detail transfer di PWA dibuka secara lokal tanpa memanggil endpoint detail transaksi pengeluaran.
- Tidak mengubah struktur database dan tidak menjalankan migrasi.


## Patch 2026-06-24 13:22:51 — Patch Admin — Transaction Detail v2

- Merapikan halaman detail transaksi Admin sebagai pola baku detail modul.
- Menambahkan tombol kembali kontekstual melalui back_url/back_label.
- Preview bukti/lampiran tetap memakai AppFileStorageService dan URL publik storage.
- Tidak mengubah struktur database dan tidak menjalankan migrasi.


## Patch 2026-06-24 13:29:35 — Patch Admin — Dokumentasi Lampiran Detail

- Menambahkan resource Admin Dokumentasi Event dan Lampiran Event di grup Data Pelaksanaan.
- Admin dapat klik baris untuk membuka halaman detail file dengan preview gambar/file.
- Detail memakai pola visual yang sama dengan detail transaksi Admin.
- Tidak mengubah struktur database dan tidak menjalankan migrasi.


## Patch 2026-06-24 13:41:13 — Patch Admin — Register Dokumentasi Lampiran Resource

- Mendaftarkan ActivityDocumentationResource dan ActivityAttachmentResource ke AdminPanelProvider.
- Menu Data Pelaksanaan menampilkan Dokumentasi Event dan Lampiran Event.
- Tidak mengubah database dan tidak menjalankan migrasi.


## Patch 2026-06-25 01:29:22 — Patch Admin — Catatan Event Detail

- Menambahkan resource Admin Catatan Event di grup Data Pelaksanaan.
- Admin dapat klik baris catatan untuk membuka detail clean.
- Detail menampilkan event, user, jenis catatan, isi catatan, status Masuk LPJ/Internal.
- Tidak mengubah database dan tidak menjalankan migrasi.


## Patch 2026-06-25 01:36:52 — Patch Admin — Catatan Event Status Isi

- Menambahkan indikator Terisi/Belum diisi pada daftar Catatan Event Admin.
- Catatan default kosong tetap bisa dibuka dan tampil tanpa error 500.
- Tidak mengubah database dan tidak menjalankan migrasi.


## Patch 2026-06-25 01:42:04 — Patch Admin — Operasional Event Detail

- Menambahkan resource Admin Peserta Event, Panitia/Pendamping, dan Rundown Event di grup Data Pelaksanaan.
- Admin dapat klik baris untuk membuka detail clean.
- Detail mengikuti pola visual detail transaksi/catatan/dokumentasi.
- Tidak mengubah database dan tidak menjalankan migrasi.
## Patch 2026-06-25 02:20:00 — Admin Monitoring Seleksi

- Menambahkan menu Admin Operasional Seleksi: Peserta Seleksi, Tahapan Seleksi, Item Tes Seleksi, dan Hasil Tes Peserta.
- Detail peserta menampilkan nomor peserta, WhatsApp, foto, catatan peserta, status registrasi, status seleksi, tahap gugur, dan hasil tes per tahap.
- Patch code-only: tidak migration dan tidak mengubah isi database.


## Patch 2026-06-25 02:30:20 — PWA Registrasi Onsite Peserta Seleksi 01

- Menambahkan API PWA untuk data seleksi peserta per event.
- Menambahkan form PWA Operasional untuk tambah calon peserta dan registrasi onsite.
- Petugas dapat input nomor peserta, WhatsApp, foto peserta, dan catatan peserta.
- Semua petugas assigned event dapat melihat peserta bersama, input tetap tercatat per petugas.
- Patch code-only: tidak migration dan tidak mengubah data lama.


## Patch 2026-06-25 02:35:57 — PWA Tambah Rundown Event

- Memperbaiki izin tambah peserta seleksi: semua petugas assigned event boleh input/registrasi peserta.
- Menambahkan API PWA operational-schedules untuk melihat dan menambah rundown event.
- Menambahkan form Tambah Rundown di PWA menu Operasional.
- Patch code-only: tidak migration dan tidak mengubah data lama.


## Patch 2026-06-25 02:58:24 — Fix PWA Blank Operasional Seleksi

- Memperbaiki crash PWA blank putih akibat useEffect Operasional Seleksi membaca isOperationalNav sebelum deklarasi.
- Mengubah dependency effect menjadi activeNav agar aman saat render awal.
- Patch code-only: tidak migration dan tidak mengubah database.


## Patch 2026-06-25 03:10:25 — PWA Operasional Correct Flow 01

- Mengubah arah operasional: Admin menjadi input utama peserta/rundown; PWA petugas fokus melihat dan update status.
- Menyembunyikan form tambah peserta dan tambah rundown dari PWA.
- Menambahkan status rundown untuk petugas: belum mulai, sedang berlangsung, selesai, terkendala.
- Menambahkan API update status rundown per petugas assigned event.
- Migration additive hanya menambah kolom status pada activity_schedules; tidak menghapus data lama.


## Patch 2026-06-25 03:19:04 — PWA Shared History + Operational Polish

- Merapikan tampilan Operasional agar lebih sesuai dengan halaman PWA lain.
- Menyembunyikan card Belum Registrasi dan Sudah Registrasi dari ringkasan Operasional.
- Mengarahkan riwayat keuangan agar terlihat bersama per event untuk petugas assigned, saldo tetap pribadi.
- Mengarahkan dokumentasi/operasional agar terlihat bersama per event untuk petugas assigned, inputter/uploader tetap tercatat.
- Patch code-only: tidak migration dan tidak menghapus data lama.


## Patch 2026-06-25 03:28:20 — Restore PWA Documentation History

- Mengembalikan tampilan riwayat dokumentasi di PWA menu Dokumentasi.
- Menambahkan kartu riwayat dokumentasi dengan thumbnail gambar dan link lampiran.
- Menambahkan form upload dokumentasi ringan di PWA.
- Melanjutkan polish tampilan Operasional agar lebih app-like.
- Patch code-only: tidak migration dan tidak mengubah data lama.\n

## Patch 2026-06-25 03:31:43 — Fix PWA Blank Dokumentasi Categories

- Memperbaiki blank putih pada menu Dokumentasi akibat documentation_categories bisa berbentuk object/map, bukan array.
- Menambahkan normalisasi kategori dokumentasi di PWA sebelum render select.
- Patch code-only: tidak migration dan tidak mengubah database.


## Patch 2026-06-25 03:36:14 — PWA Pull-to-refresh tanpa Tombol Refresh

- Menyembunyikan tombol Refresh manual pada halaman Operasional dan Dokumentasi.
- Menambahkan pull-to-refresh ringan berbasis gesture tarik ke bawah.
- Refresh tetap berada di halaman aktif, tidak pindah ke halaman lain.
- Patch code-only: tidak migration dan tidak mengubah database.\n

## Patch 2026-06-25 03:43:17 — Clean PWA Operational Documentation Edit

- Menyederhanakan header Operasional dan Dokumentasi agar cukup judul, tanpa helper text besar.
- Menghilangkan teks pull-to-refresh dari tampilan agar lebih clean.
- Menambahkan tombol Edit/Koreksi pada kartu riwayat dokumentasi.
- Menambahkan API koreksi dokumentasi untuk update kategori, caption, include flag, dan opsional ganti file.
- Patch code-only: tidak migration dan tidak mengubah data lama.


## Patch 2026-06-25 03:48:28 — Fix PWA Pull-to-refresh v2

- Memperbaiki gesture pull-to-refresh agar dipicu saat jari dilepas dari posisi paling atas halaman.
- Refresh tetap berada di halaman aktif dan tidak pindah ke halaman lain.
- Menghilangkan helper text visual pull-to-refresh agar tampilan tetap clean.
- Patch code-only: tidak migration dan tidak mengubah database.\n

## Patch 2026-06-25 03:52:04 — Fix Pull-to-refresh Keep Current Page

- Memperbaiki pull-to-refresh agar tetap di halaman/menu aktif.
- Menyimpan activeNav dan selectedLpjId ke sessionStorage agar jika browser reload, halaman terakhir dipulihkan.
- Mencegah native browser pull refresh saat gesture custom aktif.
- Patch code-only: tidak migration dan tidak mengubah database.\n

## Patch 2026-06-25 03:53:55 — Native Pull Refresh Keep Page

- Mengganti custom pull-to-refresh menjadi native pull-to-refresh Android/Chrome agar lebih stabil.
- Tetap menyimpan activeNav dan selectedLpjId agar setelah refresh tetap kembali ke halaman/menu terakhir.
- Patch code-only: tidak migration dan tidak mengubah database.\n

## Patch 2026-06-25 07:29:28 — Admin CRUD Peserta Rundown

- Menambahkan halaman create/edit Filament untuk Peserta Seleksi, Rundown Event, dan Panitia/Pendamping.
- Patch code-only: tidak migration, tidak hapus data, tidak menyentuh flow PWA User.

## 20260626_131612 — PWA Activity History & Dashboard Polish

- Dashboard: nama lembaga dibuat lebih ringkas agar muat 1 baris.
- Avatar Beranda dan Profil dibuat bulat penuh dan foto ikut ter-clip rapi.
- Activity History profil menampilkan aktivitas user login saja.
- Dokumentasi, lampiran, transaksi, transfer saldo, dana talangan, catatan, peserta/rundown terkait user masuk ke Activity History.
- Ditambahkan endpoint backend `/api/app/activity-history` agar filter aktivitas user dilakukan dari server, bukan tebak-tebakan frontend.
- Patch bersifat code-only/runtime polish; tidak ada migration/reset database.

## 20260629_115219 — Admin Polish 01 Visual Base V2

- Menambahkan polish visual global untuk Admin/Filament.
- Scope hanya tampilan: card, table, section, badge, form, sidebar, modal, dan responsive spacing.
- Revisi V2 memakai PHP CLI karena container tidak menyediakan python3.
- Tidak mengubah database, migration, role, PWA, API, atau workflow operasional.
- Commit/push belum dilakukan, menunggu validasi dan ACC.

## 20260629_115639 — Rollback Admin Polish 01 Visual Base

- Rollback polish visual global Admin/Filament karena tampilan menjadi tidak sesuai.
- Hook render CSS global `filament.admin-polish-css` dihapus dari AppServiceProvider.
- File CSS polish global dinonaktifkan dan dipindah ke backup patch.
- Tidak mengubah database, migration, PWA, API, atau workflow operasional.
- Commit/push belum dilakukan.

## 20260629_120901 — Admin Polish 02 V2 Fix Users Preview + Avatar

- Melanjutkan patch Users yang berhenti saat register route preview.
- Route Preview User berhasil ditambahkan secara robust ke UserResource.
- Tabel Users diarahkan agar klik baris membuka Preview User, bukan Edit.
- Avatar tabel Users memakai accessor proxy internal untuk menampilkan avatar dari storage/R2.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_121201 — Fix Admin Users Preview Filament V4

- Memperbaiki ViewUser.php agar kompatibel dengan Filament v4.
- Properti view diubah dari static menjadi non-static: `protected string $view`.
- Patch tetap scoped ke menu Users.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_122027 — Fix Admin Users Avatar R2 URL

- Memperbaiki avatar tabel Users agar mengambil URL dari AppFileStorageService.
- Sumber data avatar memakai `profile_photo_path` dan `profile_photo_disk`.
- Mendukung avatar yang tersimpan di R2 seperti path `event/profile-photos/...`.
- Fallback proxy tetap tersedia jika user belum memiliki avatar.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_123224 — Admin Users Username Display

- Menambahkan tampilan Username pada tabel Users.
- Menambahkan Username pada halaman Preview User.
- Avatar Users tetap memakai URL dari AppFileStorageService/R2.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_123817 — Clean Preview User Layout

- Membersihkan halaman Preview User.
- Menghapus output mentah username di bawah nama.
- Username tetap tampil di section Informasi User.
- Status Akun dipindahkan ke section Aktivitas Akun.
- Row Email Diverifikasi dihapus agar tampilan lebih clean.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_124105 — Fix Admin Users Role Display

- Memperbaiki mapping tampilan role di tabel Users dan Preview User.
- Role `director` / `direktur` sekarang tampil sebagai Direktur, bukan User Lapangan.
- Role yang belum dikenal ditampilkan secara headline agar tidak jatuh menjadi User biasa.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_124738 — Fix Users Create Route + Petugas Label

- Mengubah route Preview User dari `/admin/users/{record}` menjadi `/admin/users/{record}/preview` agar tidak bentrok dengan `/admin/users/create`.
- Label tampilan role `User Lapangan` diganti menjadi `Petugas`.
- Tombol `New user` dirapikan menjadi `Tambah User` jika pola file mendukung.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_125046 — Admin Users Form Polish

- Memoles label halaman Tambah/Edit User.
- Role tampilan dirapikan menjadi Admin, Direktur, dan Petugas.
- Label field user dibuat lebih manusiawi.
- Password diberi helper agar lebih jelas saat edit.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_125339 — Admin Event Preview 01

- Menambahkan halaman Preview Event pada resource Semua Event.
- Klik baris Event diarahkan ke Preview Event, bukan langsung Edit.
- Preview Event menampilkan ringkasan status, dana, peserta, dokumentasi, catatan, dan petugas assigned.
- Tombol Edit Event, Print LPJ, dan PDF tetap tersedia di header jika route tersedia.
- Tidak mengubah database, migration, PWA, API operasional, atau workflow Event.
- Commit/push belum dilakukan.

## 20260629_125709 — Rollback Admin Event Preview 01

- Rollback Preview Event karena halaman preview menghasilkan error 500 saat diklik.
- LpjResource dan LpjsTable dikembalikan dari backup sebelum patch.
- File ViewLpj dan view-lpj dinonaktifkan sementara.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_130539 — Admin Event Preview 01 Safe V2

- Menambahkan halaman Preview Event versi aman.
- Klik baris Event diarahkan ke Preview Event.
- Preview menampilkan ringkasan event, dana, peserta, dokumentasi, petugas, dan status.
- Script memakai auto-rollback jika syntax/route/preview menghasilkan error 500.
- Validasi preview memakai Laravel Tinker agar bootstrap aplikasi benar.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_130739 — Emergency Rollback Admin Event Preview 01 Safe V2

- Rollback Preview Event karena aplikasi/browser menghasilkan error 500 setelah patch.
- LpjResource dan LpjsTable dikembalikan dari backup sebelum patch.
- ViewLpj dan view-lpj dinonaktifkan/dihapus sementara.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_131021 — Admin Custom Event Detail

- Menambahkan custom route detail Event: `/admin/lpjs/{lpj}/detail`.
- Klik baris Semua Event diarahkan ke detail custom, bukan Filament ViewRecord.
- Detail menampilkan ringkasan Event, dana, peserta, dokumentasi, petugas, dan catatan terbaru.
- Script memakai auto-rollback jika syntax/route/render/curl menghasilkan error.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_140024 — Admin Event Detail Shell Polish

- Custom Event Detail dibuat lebih terasa sebagai bagian Admin dengan sidebar mini, topbar, dark theme, dan layout dashboard.
- Tidak kembali memakai Filament ViewRecord agar tetap aman dari error 500 sebelumnya.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_141530 — Admin Event Detail Sidebar Polish V2

- Sidebar custom Event Detail dipoles agar lebih mirip navigasi Admin/Kicap Event.
- Menu dikelompokkan menjadi menu utama, Operasional Seleksi, dan Data Pelaksanaan.
- Icon navigasi diganti SVG rapi.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_141927 — Admin Event Detail 02 Quick Links

- Menambahkan quick links pada detail Event: Peserta, Rundown, Dokumentasi, Catatan, dan Transaksi.
- Petugas Event dipoles dengan badge peran dan helper bahwa panitia/pendamping mengikuti user assigned.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_142421 — Admin Event Detail 03 Assigned Panitia/Pendamping

- Section Petugas Event diganti menjadi Panitia / Pendamping.
- Data Panitia/Pendamping internal diambil dari user yang di-assign ke event.
- Quick link dan sidebar menu Panitia/Pendamping ditambahkan dan diarahkan ke section detail.
- Activity Committees tidak dihapus; namun sumber utama tampilan internal adalah assigned users.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_142452 — Admin Event Detail 03 Assigned Panitia/Pendamping

- Section Petugas Event diganti menjadi Panitia / Pendamping.
- Data Panitia/Pendamping internal diambil dari user yang di-assign ke event.
- Quick link dan sidebar menu Panitia/Pendamping ditambahkan dan diarahkan ke section detail.
- Activity Committees tidak dihapus; namun sumber utama tampilan internal adalah assigned users.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_143024 — Remove Panitia/Pendamping Shortcut/Menu V2

- Menghapus quick card Panitia/Pendamping dari detail Event.
- Menghapus sidebar menu Panitia/Pendamping agar tidak membuka halaman/list kosong.
- Section Panitia / Pendamping tetap ada di detail Event dan tetap bersumber dari assigned users.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.

## 20260629_143306 — Hide Panitia/Pendamping Sidebar Menu

- Menu Resource Panitia/Pendamping disembunyikan dari sidebar Admin.
- Data/resource lama tidak dihapus agar aman untuk kompatibilitas.
- Sumber utama Panitia/Pendamping internal tetap assigned users pada detail Event.
- Tidak mengubah database, migration, PWA, API operasional, atau data produksi.
- Commit/push belum dilakukan.
